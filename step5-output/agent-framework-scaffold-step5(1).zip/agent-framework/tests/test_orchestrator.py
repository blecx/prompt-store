from __future__ import annotations

import sys
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from agent_framework.agents.evaluation import EvaluationAgent
from agent_framework.agents.pipeline import PipelineAgent
from agent_framework.agents.planning import PlanningAgent
from agent_framework.agents.supervisor import SupervisorAgent
from agent_framework.evaluation.strategies import DeterministicEvaluator
from agent_framework.orchestration.orchestrator import Orchestrator
from agent_framework.schemas.models import ProductDefinition, TaskState
from agent_framework.tools.builtin import EchoTool
from agent_framework.tools.registry import ToolRegistry


class TestOrchestrator(unittest.TestCase):
    def test_orchestrator_completes_single_task(self) -> None:
        registry = ToolRegistry()
        registry.register(EchoTool())

        orchestrator = Orchestrator(
            planning_agent=PlanningAgent(),
            supervisor_agent=SupervisorAgent(),
            execution_agents={"pipeline": PipelineAgent(registry)},
            evaluation_agent=EvaluationAgent(DeterministicEvaluator()),
        )

        product = ProductDefinition(
            product_id="p2",
            title="Demo",
            summary="Demo product",
            goals=["Complete workflow"],
        )
        plan = orchestrator.run(product)
        self.assertEqual(plan.task_nodes[0].state, TaskState.COMPLETED)


if __name__ == "__main__":
    unittest.main()

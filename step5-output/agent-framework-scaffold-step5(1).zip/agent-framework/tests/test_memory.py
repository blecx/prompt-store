from __future__ import annotations

import sys
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from agent_framework.memory.store import MemoryStore


class TestMemory(unittest.TestCase):
    def test_memory_store_roundtrip(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "memory.json"
            store = MemoryStore(path)
            store.store("alpha", {"value": 1})
            self.assertEqual(store.retrieve("alpha"), {"value": 1})


if __name__ == "__main__":
    unittest.main()

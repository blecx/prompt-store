from __future__ import annotations

import sys
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from agent_framework.tools.builtin import EchoTool


class TestTools(unittest.TestCase):
    def test_echo_tool(self) -> None:
        tool = EchoTool()
        result = tool.execute({"hello": "world"})
        self.assertEqual(result.status, "ok")
        self.assertEqual(result.payload["echo"]["hello"], "world")


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import sys
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from agent_framework.protocols.a2a import A2AMessageBus, AgentMessage


class TestProtocols(unittest.TestCase):
    def test_a2a_message_bus(self) -> None:
        bus = A2AMessageBus()
        bus.send(AgentMessage(message_type="TaskAssignment", sender="supervisor", receiver="worker", payload={"task_id": "t1"}))
        drained = bus.drain(receiver="worker")
        self.assertEqual(len(drained), 1)
        self.assertEqual(drained[0].payload["task_id"], "t1")


if __name__ == "__main__":
    unittest.main()

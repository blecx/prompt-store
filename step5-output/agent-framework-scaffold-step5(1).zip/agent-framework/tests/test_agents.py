from __future__ import annotations

import sys
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from agent_framework.agents.planning import PlanningAgent
from agent_framework.schemas.models import ProductDefinition


class TestPlanningAgent(unittest.TestCase):
    def test_planning_agent_returns_execution_plan(self) -> None:
        agent = PlanningAgent()
        product = ProductDefinition(
            product_id="p1",
            title="Test Product",
            summary="Test summary",
            goals=["Goal 1"],
        )
        result = agent.execute({"product_definition": product})
        self.assertEqual(result.status, "ok")
        self.assertIn("execution_plan", result.payload)


if __name__ == "__main__":
    unittest.main()

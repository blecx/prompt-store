# Agent Framework Repository Scaffold
## Python Multi-Agent System

This scaffold implements the starter structure for a local-first Python multi-agent framework.

### Current scope
- modular package layout
- task graph execution primitives
- base agent hierarchy
- orchestration runtime
- tool registry and routing hooks
- memory subsystem interfaces
- evaluation subsystem interfaces
- MCP and A2A protocol boundaries
- structured logging and event tracing
- example workflow
- unit-test starter suite

### Execution model
Product Definition  
→ Domain Decomposition  
→ Subdomain Slicing  
→ Task Graph Creation  
→ Agent Assignment  
→ Tool Invocation  
→ Evaluation  
→ Iteration  
→ Completion

### Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python examples/run_example.py
python -m unittest discover -s tests -v
```

### Notes
- The scaffold defaults to local-first execution.
- External providers such as OpenAI are optional adapter targets.
- Higgins Interface support is intentionally represented as an abstraction boundary, not a hard dependency.

from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from agent_framework.agents.evaluation import EvaluationAgent
from agent_framework.agents.pipeline import PipelineAgent
from agent_framework.agents.planning import PlanningAgent
from agent_framework.agents.supervisor import SupervisorAgent
from agent_framework.evaluation.strategies import DeterministicEvaluator
from agent_framework.orchestration.orchestrator import Orchestrator
from agent_framework.schemas.models import ProductDefinition
from agent_framework.tools.builtin import EchoTool
from agent_framework.tools.registry import ToolRegistry


def main() -> None:
    registry = ToolRegistry()
    registry.register(EchoTool())

    planning_agent = PlanningAgent()
    supervisor_agent = SupervisorAgent()
    evaluation_agent = EvaluationAgent(DeterministicEvaluator())
    pipeline_agent = PipelineAgent(registry=registry)

    orchestrator = Orchestrator(
        planning_agent=planning_agent,
        supervisor_agent=supervisor_agent,
        execution_agents={"pipeline": pipeline_agent},
        evaluation_agent=evaluation_agent,
        max_retries=1,
    )

    orchestrator.event_bus.subscribe(
        "task_completed",
        lambda event: print(f"[event] task_completed: {event.payload}"),
    )

    product = ProductDefinition(
        product_id="demo-product",
        title="Demo Agent Framework Workflow",
        summary="Build an initial architecture-oriented task execution flow.",
        goals=["Plan, execute, and evaluate one starter task."],
        acceptance_criteria=["Task execution must complete successfully."],
    )

    plan = orchestrator.run(product)
    print(f"Execution plan: {plan.plan_id}")
    for task in plan.task_nodes:
        print(f"- {task.task_id}: state={task.state.value}, outputs={task.outputs}")


if __name__ == "__main__":
    main()

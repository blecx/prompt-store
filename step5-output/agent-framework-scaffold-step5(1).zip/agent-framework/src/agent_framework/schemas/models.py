from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class TaskState(str, Enum):
    PENDING = "pending"
    PLANNED = "planned"
    ASSIGNED = "assigned"
    RUNNING = "running"
    BLOCKED = "blocked"
    AWAITING_EVALUATION = "awaiting_evaluation"
    RETRY_REQUIRED = "retry_required"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass(slots=True)
class ProductDefinition:
    product_id: str
    title: str
    summary: str
    goals: List[str]
    constraints: List[str] = field(default_factory=list)
    acceptance_criteria: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class Domain:
    domain_id: str
    name: str
    description: str
    product_id: str
    subdomains: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class Subdomain:
    subdomain_id: str
    domain_id: str
    name: str
    description: str
    work_items: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class WorkItem:
    work_item_id: str
    subdomain_id: str
    title: str
    description: str
    required_capabilities: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    acceptance_criteria: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class TaskNode:
    task_id: str
    title: str
    description: str
    work_item_id: Optional[str]
    state: TaskState = TaskState.PENDING
    assigned_agent: Optional[str] = None
    required_capabilities: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    inputs: Dict[str, Any] = field(default_factory=dict)
    outputs: Dict[str, Any] = field(default_factory=dict)
    retry_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class ExecutionPlan:
    plan_id: str
    product_definition: ProductDefinition
    domains: List[Domain] = field(default_factory=list)
    subdomains: List[Subdomain] = field(default_factory=list)
    work_items: List[WorkItem] = field(default_factory=list)
    task_nodes: List[TaskNode] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class AcceptanceCriteria:
    criteria_id: str
    description: str
    rule_type: str
    expected_value: Any = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class QualityScore:
    score: float
    dimensions: Dict[str, float] = field(default_factory=dict)
    rationale: str = ""


@dataclass(slots=True)
class EvaluationPlan:
    evaluation_id: str
    task_id: str
    criteria: List[AcceptanceCriteria] = field(default_factory=list)
    use_llm_judge: bool = False
    require_human_review: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class EvaluationResult:
    evaluation_id: str
    task_id: str
    passed: bool
    quality_score: QualityScore
    findings: List[str] = field(default_factory=list)
    failure_diagnosis: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class ToolCallRecord:
    tool_name: str
    input_payload: Dict[str, Any]
    output_payload: Dict[str, Any]
    status: str
    error: Optional[str] = None

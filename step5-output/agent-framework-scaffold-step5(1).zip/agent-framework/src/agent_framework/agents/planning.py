from __future__ import annotations

from typing import Dict

from agent_framework.schemas.models import Domain, ExecutionPlan, ProductDefinition, Subdomain, TaskNode, WorkItem
from .base import AgentResult, BaseAgent


class PlanningAgent(BaseAgent):
    def __init__(self) -> None:
        super().__init__(name="planning", capabilities=["planning", "decomposition"])

    def execute(self, payload: Dict[str, object]) -> AgentResult:
        self.before_execute(payload)
        product: ProductDefinition = payload["product_definition"]  # type: ignore[assignment]

        domain = Domain(
            domain_id="domain-core",
            name="core_domain",
            description="Primary product domain extracted from product definition.",
            product_id=product.product_id,
            subdomains=["subdomain-core"],
        )
        subdomain = Subdomain(
            subdomain_id="subdomain-core",
            domain_id=domain.domain_id,
            name="core_subdomain",
            description="Primary subdomain for starter workflow execution.",
            work_items=["workitem-1"],
        )
        work_item = WorkItem(
            work_item_id="workitem-1",
            subdomain_id=subdomain.subdomain_id,
            title="Create initial solution outline",
            description="Generate an initial implementation-oriented outline.",
            required_capabilities=["pipeline"],
            acceptance_criteria=["Must generate an outline artifact."],
        )
        task = TaskNode(
            task_id="task-1",
            title=work_item.title,
            description=work_item.description,
            work_item_id=work_item.work_item_id,
            required_capabilities=work_item.required_capabilities,
            dependencies=[],
            inputs={"summary": product.summary, "tool_name": "echo"},
        )

        plan = ExecutionPlan(
            plan_id=f"plan-{product.product_id}",
            product_definition=product,
            domains=[domain],
            subdomains=[subdomain],
            work_items=[work_item],
            task_nodes=[task],
        )

        result = AgentResult(status="ok", payload={"execution_plan": plan})
        self.after_execute(result)
        return result

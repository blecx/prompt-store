from __future__ import annotations

from typing import Dict

from agent_framework.evaluation.base import BaseEvaluator
from .base import AgentResult, BaseAgent


class EvaluationAgent(BaseAgent):
    def __init__(self, evaluator: BaseEvaluator) -> None:
        super().__init__(name="evaluation", capabilities=["evaluation"])
        self.evaluator = evaluator

    def execute(self, payload: Dict[str, object]) -> AgentResult:
        self.before_execute(payload)
        task_output = payload["task_output"]  # type: ignore[assignment]
        evaluation_plan = payload["evaluation_plan"]  # type: ignore[assignment]
        evaluation_result = self.evaluator.evaluate(task_output, evaluation_plan)
        result = AgentResult(status="ok", payload={"evaluation_result": evaluation_result})
        self.after_execute(result)
        return result

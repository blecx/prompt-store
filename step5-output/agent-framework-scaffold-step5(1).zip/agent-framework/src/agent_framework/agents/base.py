from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from agent_framework.runtime.logging import get_logger


@dataclass(slots=True)
class AgentResult:
    status: str
    payload: Dict[str, Any] = field(default_factory=dict)
    findings: List[str] = field(default_factory=list)
    error: Optional[str] = None


class BaseAgent:
    def __init__(
        self,
        name: str,
        capabilities: Optional[List[str]] = None,
        max_retries: int = 1,
    ) -> None:
        self.name = name
        self.capabilities = capabilities or []
        self.max_retries = max_retries
        self.logger = get_logger(f"agent_framework.agent.{self.name}")

    def can_handle(self, required_capabilities: List[str]) -> bool:
        return all(cap in self.capabilities for cap in required_capabilities)

    def execute(self, payload: Dict[str, Any]) -> AgentResult:
        raise NotImplementedError

    def before_execute(self, payload: Dict[str, Any]) -> None:
        self.logger.info("Executing with payload keys=%s", list(payload.keys()))

    def after_execute(self, result: AgentResult) -> None:
        self.logger.info("Execution completed with status=%s", result.status)

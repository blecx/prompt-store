from __future__ import annotations

from typing import Dict

from agent_framework.memory.store import MemoryStore
from .base import AgentResult, BaseAgent


class MemoryAgent(BaseAgent):
    def __init__(self, memory_store: MemoryStore) -> None:
        super().__init__(name="memory", capabilities=["memory"])
        self.memory_store = memory_store

    def execute(self, payload: Dict[str, object]) -> AgentResult:
        self.before_execute(payload)
        action = payload.get("action")
        if action == "store":
            self.memory_store.store(str(payload["key"]), payload["value"])
            result = AgentResult(status="ok", findings=[f"Stored key={payload['key']}"])
        elif action == "retrieve":
            value = self.memory_store.retrieve(str(payload["key"]))
            result = AgentResult(status="ok", payload={"value": value})
        else:
            result = AgentResult(status="failed", error="Unsupported memory action.")
        self.after_execute(result)
        return result

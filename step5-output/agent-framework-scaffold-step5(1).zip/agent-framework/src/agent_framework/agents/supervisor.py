from __future__ import annotations

from typing import Dict, Optional

from agent_framework.schemas.models import TaskNode
from .base import AgentResult, BaseAgent


class SupervisorAgent(BaseAgent):
    def __init__(self) -> None:
        super().__init__(name="supervisor", capabilities=["supervision", "assignment"])

    def execute(self, payload: Dict[str, object]) -> AgentResult:
        self.before_execute(payload)
        task: TaskNode = payload["task"]  # type: ignore[assignment]
        available_agents: Dict[str, BaseAgent] = payload["available_agents"]  # type: ignore[assignment]

        selected_name: Optional[str] = None
        for name, agent in available_agents.items():
            if agent.can_handle(task.required_capabilities):
                selected_name = name
                break

        if not selected_name:
            result = AgentResult(status="failed", error=f"No agent found for task {task.task_id}")
        else:
            result = AgentResult(
                status="ok",
                payload={"assigned_agent": selected_name},
                findings=[f"Assigned task {task.task_id} to agent {selected_name}"],
            )
        self.after_execute(result)
        return result

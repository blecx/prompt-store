from __future__ import annotations

from typing import Dict

from agent_framework.tools.registry import ToolRegistry
from .base import AgentResult, BaseAgent


class ToolRouterAgent(BaseAgent):
    def __init__(self, registry: ToolRegistry) -> None:
        super().__init__(name="tool_router", capabilities=["tool_routing"])
        self.registry = registry

    def execute(self, payload: Dict[str, object]) -> AgentResult:
        self.before_execute(payload)
        requested_tool = str(payload.get("tool_name", ""))
        tool = self.registry.get(requested_tool)
        if tool is None:
            result = AgentResult(status="failed", error=f"Tool not found: {requested_tool}")
        else:
            result = AgentResult(
                status="ok",
                payload={
                    "tool_name": tool.name,
                    "tool_category": tool.category,
                    "read_only": tool.read_only,
                },
            )
        self.after_execute(result)
        return result

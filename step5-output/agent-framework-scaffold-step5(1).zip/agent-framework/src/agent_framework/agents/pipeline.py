from __future__ import annotations

from typing import Dict

from agent_framework.tools.registry import ToolRegistry
from .base import AgentResult, BaseAgent


class PipelineAgent(BaseAgent):
    def __init__(self, registry: ToolRegistry) -> None:
        super().__init__(name="pipeline", capabilities=["pipeline"])
        self.registry = registry

    def execute(self, payload: Dict[str, object]) -> AgentResult:
        self.before_execute(payload)
        tool_name = str(payload.get("tool_name", "echo"))
        tool = self.registry.get(tool_name)
        if tool is None:
            result = AgentResult(status="failed", error=f"Pipeline tool not found: {tool_name}")
        else:
            tool_result = tool.execute({"task_payload": payload})
            result = AgentResult(status="ok", payload={"tool_result": tool_result.payload})
        self.after_execute(result)
        return result

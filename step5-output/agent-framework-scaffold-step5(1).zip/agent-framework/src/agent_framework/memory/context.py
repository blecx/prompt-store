from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Dict, Iterable, List


class RetrievalIndex:
    def __init__(self) -> None:
        self._documents: Dict[str, Dict[str, Any]] = {}

    def add_document(self, doc_id: str, document: Dict[str, Any]) -> None:
        self._documents[doc_id] = document

    def query(self, text: str) -> List[Dict[str, Any]]:
        results = []
        lowered = text.lower()
        for _, doc in self._documents.items():
            blob = str(doc).lower()
            if lowered in blob:
                results.append(doc)
        return results


class ContextAssembler:
    def assemble(self, *parts: Iterable[Any]) -> Dict[str, Any]:
        assembled: Dict[str, Any] = {"parts": []}
        for part_group in parts:
            for part in part_group:
                if is_dataclass(part):
                    assembled["parts"].append(asdict(part))
                else:
                    assembled["parts"].append(part)
        return assembled

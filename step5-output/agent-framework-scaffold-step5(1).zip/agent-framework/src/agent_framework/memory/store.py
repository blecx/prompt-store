from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional


class MemoryStore:
    def __init__(self, storage_path: str | Path = ".agent_memory.json") -> None:
        self.storage_path = Path(storage_path)
        if not self.storage_path.exists():
            self.storage_path.write_text("{}", encoding="utf-8")

    def _read(self) -> Dict[str, Any]:
        return json.loads(self.storage_path.read_text(encoding="utf-8"))

    def _write(self, data: Dict[str, Any]) -> None:
        self.storage_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def store(self, key: str, value: Any) -> None:
        data = self._read()
        data[key] = value
        self._write(data)

    def retrieve(self, key: str) -> Optional[Any]:
        return self._read().get(key)


class TaskStateStore(MemoryStore):
    """Persistent store for task node state snapshots."""


class ArtifactStore(MemoryStore):
    """Persistent store for generated artifacts and references."""

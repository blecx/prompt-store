from __future__ import annotations

from typing import Any, Dict


class BaseModelBackend:
    provider_name: str = "base"

    def generate(self, prompt: str, **kwargs: Any) -> Dict[str, Any]:
        raise NotImplementedError


class DummyModelBackend(BaseModelBackend):
    provider_name = "dummy"

    def generate(self, prompt: str, **kwargs: Any) -> Dict[str, Any]:
        return {
            "provider": self.provider_name,
            "content": f"Dummy response for prompt: {prompt[:120]}",
            "metadata": kwargs,
        }


class OpenAIModelBackend(BaseModelBackend):
    provider_name = "openai"

    def generate(self, prompt: str, **kwargs: Any) -> Dict[str, Any]:
        return {
            "provider": self.provider_name,
            "content": "OpenAI backend adapter placeholder.",
            "metadata": {"prompt": prompt, **kwargs},
        }


class HigginsModelBackend(BaseModelBackend):
    provider_name = "higgins_interface"

    def generate(self, prompt: str, **kwargs: Any) -> Dict[str, Any]:
        return {
            "provider": self.provider_name,
            "content": "Higgins Interface adapter placeholder.",
            "metadata": {"prompt": prompt, **kwargs},
        }

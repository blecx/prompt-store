from __future__ import annotations

from typing import Any, Dict


class MCPClient:
    """
    Internal wrapper boundary for MCP-compatible tools or services.
    Low-level transport is intentionally abstracted away in this scaffold.
    """

    def call_tool(self, tool_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "status": "not_implemented",
            "tool_name": tool_name,
            "payload": payload,
        }

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone, timezone
from typing import Any, Dict, List, Optional


@dataclass(slots=True)
class AgentMessage:
    message_type: str
    sender: str
    receiver: str
    payload: Dict[str, Any]
    correlation_id: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class A2AMessageBus:
    def __init__(self) -> None:
        self._messages: List[AgentMessage] = []

    def send(self, message: AgentMessage) -> None:
        self._messages.append(message)

    def drain(self, receiver: Optional[str] = None) -> List[AgentMessage]:
        if receiver is None:
            messages = list(self._messages)
            self._messages.clear()
            return messages
        matched = [msg for msg in self._messages if msg.receiver == receiver]
        self._messages = [msg for msg in self._messages if msg.receiver != receiver]
        return matched

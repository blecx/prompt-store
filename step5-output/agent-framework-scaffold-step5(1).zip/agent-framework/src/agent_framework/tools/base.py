from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


class ToolExecutionError(RuntimeError):
    """Raised when a tool execution fails."""


@dataclass(slots=True)
class ToolResult:
    status: str
    payload: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class BaseTool:
    name: str = "base_tool"
    description: str = "Base tool interface"
    category: str = "generic"
    read_only: bool = True
    required_permissions: List[str] = []

    def validate_input(self, input_data: Dict[str, Any]) -> None:
        if not isinstance(input_data, dict):
            raise ToolExecutionError("Tool input must be a dictionary.")

    def execute(self, input_data: Dict[str, Any]) -> ToolResult:
        raise NotImplementedError("Tools must implement execute().")

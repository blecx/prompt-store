from __future__ import annotations

from typing import Dict

from .base import BaseTool, ToolResult


class EchoTool(BaseTool):
    name = "echo"
    description = "Returns the input payload unchanged."
    category = "utility"
    read_only = True

    def execute(self, input_data: Dict[str, object]) -> ToolResult:
        self.validate_input(input_data)
        return ToolResult(status="ok", payload={"echo": input_data})

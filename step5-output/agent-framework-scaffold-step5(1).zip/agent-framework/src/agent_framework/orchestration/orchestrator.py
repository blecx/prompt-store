from __future__ import annotations

from dataclasses import asdict
from typing import Dict, Optional

from agent_framework.agents.base import BaseAgent
from agent_framework.agents.evaluation import EvaluationAgent
from agent_framework.agents.planning import PlanningAgent
from agent_framework.agents.supervisor import SupervisorAgent
from agent_framework.orchestration.task_graph import TaskGraph
from agent_framework.runtime.events import Event, EventBus
from agent_framework.runtime.logging import get_logger
from agent_framework.schemas.models import (
    AcceptanceCriteria,
    EvaluationPlan,
    ExecutionPlan,
    ProductDefinition,
    TaskState,
)


class Orchestrator:
    def __init__(
        self,
        planning_agent: PlanningAgent,
        supervisor_agent: SupervisorAgent,
        execution_agents: Dict[str, BaseAgent],
        evaluation_agent: EvaluationAgent,
        event_bus: Optional[EventBus] = None,
        max_retries: int = 1,
    ) -> None:
        self.planning_agent = planning_agent
        self.supervisor_agent = supervisor_agent
        self.execution_agents = execution_agents
        self.evaluation_agent = evaluation_agent
        self.event_bus = event_bus or EventBus()
        self.max_retries = max_retries
        self.logger = get_logger("agent_framework.orchestrator")

    def _publish(self, event_type: str, payload: Dict[str, object]) -> None:
        self.event_bus.publish(Event(event_type=event_type, payload=payload))

    def plan(self, product_definition: ProductDefinition) -> ExecutionPlan:
        result = self.planning_agent.execute({"product_definition": product_definition})
        if result.status != "ok":
            raise RuntimeError(result.error or "Planning failed.")
        return result.payload["execution_plan"]

    def run(self, product_definition: ProductDefinition) -> ExecutionPlan:
        execution_plan = self.plan(product_definition)
        graph = TaskGraph()
        for task in execution_plan.task_nodes:
            task.state = TaskState.PLANNED
            graph.add_task(task)

        while not graph.is_complete() and not graph.has_failed():
            ready_tasks = graph.ready_tasks()
            if not ready_tasks:
                self.logger.warning("No ready tasks available. Stopping.")
                break

            for task in ready_tasks:
                task.state = TaskState.ASSIGNED
                assignment = self.supervisor_agent.execute(
                    {"task": task, "available_agents": self.execution_agents}
                )
                if assignment.status != "ok":
                    task.state = TaskState.FAILED
                    task.outputs["error"] = assignment.error
                    self._publish("task_failed", {"task_id": task.task_id, "error": assignment.error})
                    continue

                agent_name = str(assignment.payload["assigned_agent"])
                task.assigned_agent = agent_name
                agent = self.execution_agents[agent_name]

                task.state = TaskState.RUNNING
                self._publish("task_started", {"task_id": task.task_id, "agent": agent_name})
                result = agent.execute(task.inputs)

                if result.status != "ok":
                    task.retry_count += 1
                    if task.retry_count > self.max_retries:
                        task.state = TaskState.FAILED
                        task.outputs["error"] = result.error
                        self._publish("task_failed", {"task_id": task.task_id, "error": result.error})
                    else:
                        task.state = TaskState.RETRY_REQUIRED
                        self._publish("task_retry_required", {"task_id": task.task_id})
                    continue

                task.outputs = result.payload
                task.state = TaskState.AWAITING_EVALUATION

                evaluation_plan = EvaluationPlan(
                    evaluation_id=f"eval-{task.task_id}",
                    task_id=task.task_id,
                    criteria=[
                        AcceptanceCriteria(
                            criteria_id=f"criterion-{task.task_id}",
                            description="Task output must include tool_result",
                            rule_type="contains_key",
                            expected_value="tool_result",
                        )
                    ],
                )
                evaluation = self.evaluation_agent.execute(
                    {"task_output": task.outputs, "evaluation_plan": evaluation_plan}
                )
                evaluation_result = evaluation.payload["evaluation_result"]
                task.outputs["evaluation_result"] = asdict(evaluation_result)

                if evaluation_result.passed:
                    task.state = TaskState.COMPLETED
                    self._publish("task_completed", {"task_id": task.task_id})
                else:
                    task.retry_count += 1
                    if task.retry_count > self.max_retries:
                        task.state = TaskState.FAILED
                        self._publish("task_failed", {"task_id": task.task_id, "error": "Evaluation failed"})
                    else:
                        task.state = TaskState.RETRY_REQUIRED
                        self._publish("task_retry_required", {"task_id": task.task_id, "reason": "evaluation_failed"})

        return execution_plan

from __future__ import annotations

from typing import Dict, List

from agent_framework.schemas.models import TaskNode, TaskState


class TaskGraph:
    def __init__(self) -> None:
        self._tasks: Dict[str, TaskNode] = {}

    def add_task(self, task: TaskNode) -> None:
        self._tasks[task.task_id] = task

    def get_task(self, task_id: str) -> TaskNode:
        return self._tasks[task_id]

    def tasks(self) -> List[TaskNode]:
        return list(self._tasks.values())

    def ready_tasks(self) -> List[TaskNode]:
        ready: List[TaskNode] = []
        for task in self._tasks.values():
            if task.state not in {TaskState.PLANNED, TaskState.RETRY_REQUIRED}:
                continue
            if all(self._tasks[dep].state == TaskState.COMPLETED for dep in task.dependencies):
                ready.append(task)
        return ready

    def is_complete(self) -> bool:
        return all(task.state == TaskState.COMPLETED for task in self._tasks.values())

    def has_failed(self) -> bool:
        return any(task.state == TaskState.FAILED for task in self._tasks.values())

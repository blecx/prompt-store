from __future__ import annotations

from typing import Any, Dict

from agent_framework.schemas.models import EvaluationPlan, EvaluationResult, QualityScore
from .base import BaseEvaluator


class DeterministicEvaluator(BaseEvaluator):
    name = "deterministic"

    def evaluate(self, task_output: Dict[str, Any], plan: EvaluationPlan) -> EvaluationResult:
        findings = []
        passed = True
        for criterion in plan.criteria:
            if criterion.rule_type == "contains_key":
                key = str(criterion.expected_value)
                if key not in task_output:
                    passed = False
                    findings.append(f"Missing required key: {key}")
        score = 1.0 if passed else 0.0
        return EvaluationResult(
            evaluation_id=plan.evaluation_id,
            task_id=plan.task_id,
            passed=passed,
            quality_score=QualityScore(score=score, dimensions={"deterministic": score}),
            findings=findings,
            failure_diagnosis=None if passed else "Deterministic checks failed.",
        )


class LLMJudgeEvaluator(BaseEvaluator):
    name = "llm_judge"

    def evaluate(self, task_output: Dict[str, Any], plan: EvaluationPlan) -> EvaluationResult:
        return EvaluationResult(
            evaluation_id=plan.evaluation_id,
            task_id=plan.task_id,
            passed=True,
            quality_score=QualityScore(score=0.8, dimensions={"semantic": 0.8}, rationale="Placeholder LLM-judge score."),
            findings=["LLM-assisted evaluation placeholder."],
            failure_diagnosis=None,
        )


class ManualReviewEvaluator(BaseEvaluator):
    name = "manual_review"

    def evaluate(self, task_output: Dict[str, Any], plan: EvaluationPlan) -> EvaluationResult:
        return EvaluationResult(
            evaluation_id=plan.evaluation_id,
            task_id=plan.task_id,
            passed=False,
            quality_score=QualityScore(score=0.0, dimensions={"manual": 0.0}, rationale="Awaiting human review."),
            findings=["Manual review required."],
            failure_diagnosis="Pending human approval.",
        )

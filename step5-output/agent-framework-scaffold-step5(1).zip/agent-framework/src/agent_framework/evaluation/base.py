from __future__ import annotations

from typing import Any, Dict

from agent_framework.schemas.models import EvaluationPlan, EvaluationResult


class BaseEvaluator:
    name: str = "base_evaluator"

    def evaluate(self, task_output: Dict[str, Any], plan: EvaluationPlan) -> EvaluationResult:
        raise NotImplementedError
